import { Layout } from "../components/Layout";
import { TrendingUp, Heart, Copy, Eye } from "lucide-react";
import { useState } from "react";

export const Leaderboard = () => {
  const [timeframe, setTimeframe] = useState<"7d" | "30d" | "90d">("30d");

  const leaderboardData = [
    {
      rank: 1,
      address: "0x742d...57a",
      label: "Vitalik Buterin",
      roi: 45.2,
      pnl: 450000,
      portfolio: 2450000,
      followers: 15420,
    },
    {
      rank: 2,
      address: "0xabcd...efgh",
      label: "Top Trader Elite",
      roi: 38.5,
      pnl: 385000,
      portfolio: 1890000,
      followers: 12150,
    },
    {
      rank: 3,
      address: "0x1234...5678",
      label: "DeFi Master",
      roi: 32.8,
      pnl: 280000,
      portfolio: 1200500,
      followers: 8950,
    },
    {
      rank: 4,
      address: "0xfedc...ba98",
      label: "Solana Wizard",
      roi: 28.3,
      pnl: 180000,
      portfolio: 890250,
      followers: 5420,
    },
    {
      rank: 5,
      address: "0x5678...1234",
      label: "Arbitrage King",
      roi: 25.1,
      pnl: 150000,
      portfolio: 750000,
      followers: 3890,
    },
  ];

  return (
    <Layout>
      <div className="p-4 md:p-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold mb-4">Leaderboard</h1>

          {/* Filters */}
          <div className="flex flex-wrap gap-2">
            {(["7d", "30d", "90d"] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  timeframe === tf
                    ? "bg-gradient-to-r from-cyan-500 to-purple-500 text-white"
                    : "glass-dark hover:bg-white/10"
                }`}
              >
                {tf.toUpperCase()} ROI
              </button>
            ))}
          </div>
        </div>

        {/* Leaderboard Table */}
        <section className="glass-effect rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-white/10">
                <tr className="bg-white/5">
                  <th className="px-6 py-4 text-left text-sm font-semibold text-muted-foreground">
                    Rank
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-muted-foreground">
                    Trader
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-muted-foreground">
                    ROI
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-muted-foreground">
                    PnL
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-muted-foreground">
                    Portfolio
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-muted-foreground">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody>
                {leaderboardData.map((trader, index) => (
                  <tr
                    key={trader.rank}
                    className={`border-b border-white/10 hover:bg-white/5 transition-colors ${
                      index === 0
                        ? "bg-gradient-to-r from-cyan-500/10 to-purple-500/10"
                        : ""
                    }`}
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {index < 3 && (
                          <span className="text-lg">
                            {index === 0 ? "🥇" : index === 1 ? "🥈" : "🥉"}
                          </span>
                        )}
                        <span className="font-semibold text-lg">
                          #{trader.rank}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full glass-dark flex items-center justify-center font-bold text-cyan-400">
                          {trader.label.charAt(0)}
                        </div>
                        <div>
                          <p className="font-semibold">{trader.label}</p>
                          <p className="text-xs text-muted-foreground">
                            {trader.address}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-green-400 font-semibold">
                        <TrendingUp className="w-4 h-4" />
                        {trader.roi.toFixed(1)}%
                      </div>
                    </td>
                    <td className="px-6 py-4 font-semibold">
                      ${(trader.pnl / 1000).toFixed(0)}K
                    </td>
                    <td className="px-6 py-4 font-semibold">
                      ${(trader.portfolio / 1000000).toFixed(2)}M
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button className="p-2 hover:bg-white/10 rounded-lg transition-colors text-cyan-400 hover:text-cyan-300">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-2 hover:bg-white/10 rounded-lg transition-colors text-purple-400 hover:text-purple-300">
                          <Heart className="w-4 h-4" />
                        </button>
                        <button className="p-2 hover:bg-white/10 rounded-lg transition-colors text-green-400 hover:text-green-300">
                          <Copy className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Stats Cards */}
        <section className="grid md:grid-cols-3 gap-4">
          <div className="glass-effect p-6 rounded-xl">
            <p className="text-sm text-muted-foreground mb-2">
              Average ROI (Top 10)
            </p>
            <p className="text-3xl font-bold text-green-400">+34.2%</p>
          </div>
          <div className="glass-effect p-6 rounded-xl">
            <p className="text-sm text-muted-foreground mb-2">
              Total Followers (Top 10)
            </p>
            <p className="text-3xl font-bold">145.2K</p>
          </div>
          <div className="glass-effect p-6 rounded-xl">
            <p className="text-sm text-muted-foreground mb-2">
              Avg Portfolio Value
            </p>
            <p className="text-3xl font-bold">$1.24M</p>
          </div>
        </section>
      </div>
    </Layout>
  );
};
