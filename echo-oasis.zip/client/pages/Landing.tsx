import { useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Zap, TrendingUp, Share2 } from "lucide-react";

const CryptoLogo = ({
  delay,
  left,
  top,
}: {
  delay: number;
  left: string;
  top: string;
}) => {
  const symbols = ["₿", "Ξ", "◊", "●", "★", "◆"];
  const symbol = symbols[Math.floor(Math.random() * symbols.length)];

  return (
    <div
      className="absolute text-cyan-500/20 font-bold text-4xl animate-float"
      style={{
        left,
        top,
        animationDelay: `${delay}s`,
      }}
    >
      {symbol}
    </div>
  );
};

export const Landing = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const particles: Array<{
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
    }> = [];

    const createParticle = () => {
      return {
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        life: Math.random() * 200 + 100,
      };
    };

    for (let i = 0; i < 50; i++) {
      particles.push(createParticle());
    }

    const animate = () => {
      ctx.fillStyle = "rgba(13, 110, 253, 0.02)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach((p, i) => {
        p.x += p.vx;
        p.y += p.vy;
        p.life--;

        if (p.life <= 0) {
          particles[i] = createParticle();
        }

        const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, 5);
        gradient.addColorStop(0, `rgba(0, 255, 255, ${p.life / 200})`);
        gradient.addColorStop(1, `rgba(147, 51, 234, ${p.life / 400})`);

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
        ctx.fill();
      });

      requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-purple-900/30 overflow-hidden">
      <canvas
        ref={canvasRef}
        className="fixed inset-0 opacity-40 z-0 pointer-events-none"
      />

      {/* Floating Cryptos */}
      <div className="fixed inset-0 pointer-events-none z-1 overflow-hidden">
        <CryptoLogo delay={0} left="10%" top="15%" />
        <CryptoLogo delay={0.5} left="80%" top="20%" />
        <CryptoLogo delay={1} left="15%" top="70%" />
        <CryptoLogo delay={1.5} left="75%" top="65%" />
        <CryptoLogo delay={2} left="20%" top="40%" />
        <CryptoLogo delay={2.5} left="85%" top="45%" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
        {/* Navigation */}
        <nav className="absolute top-0 left-0 right-0 h-16 flex items-center justify-center md:justify-between px-6">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg gradient-cyan-purple flex items-center justify-center">
              <span className="text-white font-bold text-sm">D</span>
            </div>
            <span className="hidden sm:inline gradient-text font-bold text-lg">
              DeFiLens
            </span>
          </Link>
          <div className="hidden md:flex items-center gap-6">
            <a
              href="#features"
              className="text-sm text-foreground/70 hover:text-foreground transition"
            >
              Features
            </a>
            <a
              href="#how-it-works"
              className="text-sm text-foreground/70 hover:text-foreground transition"
            >
              How it works
            </a>
          </div>
        </nav>

        {/* Hero Section */}
        <div className="max-w-4xl mx-auto text-center space-y-6 mb-12">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight">
            <span className="block mb-2">Track, Follow & Copy</span>
            <span className="gradient-text">Top DeFi Traders</span>
          </h1>

          <p className="text-lg md:text-xl text-foreground/70 max-w-2xl mx-auto leading-relaxed">
            Real-time social trading dashboard powered by Zerion. Monitor wallet
            performance, replicate winning trades, and join the next generation
            of decentralized finance.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link
              to="/dashboard"
              className="btn-primary flex items-center gap-2 w-full sm:w-auto justify-center"
            >
              <span>Connect Wallet</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <button className="btn-secondary w-full sm:w-auto">
              Try Demo Wallet
            </button>
          </div>
        </div>

        {/* Features Preview */}
        <div className="grid md:grid-cols-3 gap-4 w-full max-w-4xl mt-20">
          <div className="glass-effect p-6 rounded-xl hover:border-cyan-500/50 transition-all duration-300 group">
            <Zap className="w-8 h-8 text-cyan-400 mb-3 group-hover:animate-pulse" />
            <h3 className="font-semibold mb-2">Real-Time PnL</h3>
            <p className="text-sm text-foreground/60">
              Monitor portfolio performance and profit/loss across all chains
            </p>
          </div>

          <div className="glass-effect p-6 rounded-xl hover:border-purple-500/50 transition-all duration-300 group">
            <TrendingUp className="w-8 h-8 text-purple-400 mb-3 group-hover:animate-pulse" />
            <h3 className="font-semibold mb-2">Copy Trades</h3>
            <p className="text-sm text-foreground/60">
              Instantly replicate trades from top-performing wallets
            </p>
          </div>

          <div className="glass-effect p-6 rounded-xl hover:border-cyan-500/50 transition-all duration-300 group">
            <Share2 className="w-8 h-8 text-cyan-400 mb-3 group-hover:animate-pulse" />
            <h3 className="font-semibold mb-2">Social Features</h3>
            <p className="text-sm text-foreground/60">
              Follow traders and share your insights with the community
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Gradient */}
      <div className="fixed bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent pointer-events-none" />
    </div>
  );
};
