import { Layout } from "../components/Layout";
import { Sparkles, TrendingUp, AlertCircle, Zap } from "lucide-react";

export const Insights = () => {
  const insights = [
    {
      id: 1,
      title: "Portfolio Performance",
      description:
        "Your wallet's SOL exposure increased by 25% this week. You outperformed 68% of traders in your risk group.",
      category: "performance",
      confidence: 95,
    },
    {
      id: 2,
      title: "Risk Alert",
      description:
        "Concentration risk detected: 45% of your portfolio is in volatile assets. Consider diversifying into stablecoins.",
      category: "risk",
      confidence: 87,
    },
    {
      id: 3,
      title: "Opportunity Score",
      description:
        "Based on similar traders' activity, ETH shows promising upside momentum. Top performers are accumulating at current levels.",
      category: "opportunity",
      confidence: 72,
    },
    {
      id: 4,
      title: "Trading Pattern",
      description:
        "Your average trade size increased by 35% last week. This correlates with improved ROI (+8.2%) compared to your 30-day average.",
      category: "pattern",
      confidence: 88,
    },
  ];

  const getCategoryColor = (
    category: string,
  ):
    | "text-cyan-400"
    | "text-red-400"
    | "text-green-400"
    | "text-purple-400" => {
    switch (category) {
      case "performance":
        return "text-green-400";
      case "risk":
        return "text-red-400";
      case "opportunity":
        return "text-cyan-400";
      default:
        return "text-purple-400";
    }
  };

  const getCategoryBg = (category: string) => {
    switch (category) {
      case "performance":
        return "bg-green-500/10 border-green-500/30";
      case "risk":
        return "bg-red-500/10 border-red-500/30";
      case "opportunity":
        return "bg-cyan-500/10 border-cyan-500/30";
      default:
        return "bg-purple-500/10 border-purple-500/30";
    }
  };

  return (
    <Layout>
      <div className="p-4 md:p-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">AI Insights</h1>
          <p className="text-muted-foreground">
            Powered by advanced on-chain analysis and machine learning
          </p>
        </div>

        {/* Summary Stats */}
        <section className="grid md:grid-cols-2 gap-4">
          <div className="glass-effect p-6 rounded-xl border-l-4 border-cyan-500">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">
                  Overall Health Score
                </p>
                <p className="text-4xl font-bold gradient-text">78/100</p>
              </div>
              <Sparkles className="w-8 h-8 text-cyan-400" />
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              Your portfolio is well-balanced with moderate growth potential
            </p>
          </div>

          <div className="glass-effect p-6 rounded-xl border-l-4 border-purple-500">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-2">Risk Level</p>
                <p className="text-4xl font-bold text-yellow-400">Medium</p>
              </div>
              <AlertCircle className="w-8 h-8 text-yellow-400" />
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              Monitor concentration in volatile assets
            </p>
          </div>
        </section>

        {/* AI Insights Cards */}
        <section className="space-y-4">
          <h2 className="text-xl font-bold">Latest Insights</h2>
          {insights.map((insight) => (
            <div
              key={insight.id}
              className={`glass-effect p-6 rounded-xl border ${getCategoryBg(
                insight.category,
              )}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3 flex-1">
                  <Zap
                    className={`w-5 h-5 flex-shrink-0 mt-1 ${getCategoryColor(insight.category)}`}
                  />
                  <div>
                    <h3 className="font-semibold text-lg">{insight.title}</h3>
                    <p className="text-foreground/70 mt-2">
                      {insight.description}
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-24 h-2 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-purple-500"
                      style={{ width: `${insight.confidence}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {insight.confidence}% confidence
                  </span>
                </div>
                <button className="btn-secondary py-1 px-3 text-sm">
                  Learn More
                </button>
              </div>
            </div>
          ))}
        </section>

        {/* AI Analysis Settings */}
        <section className="glass-effect p-6 rounded-xl">
          <h2 className="text-lg font-bold mb-4">Analysis Preferences</h2>
          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                defaultChecked
                className="w-4 h-4 rounded"
              />
              <span className="text-sm">Risk alerts</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                defaultChecked
                className="w-4 h-4 rounded"
              />
              <span className="text-sm">Trading opportunities</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <input
                type="checkbox"
                defaultChecked
                className="w-4 h-4 rounded"
              />
              <span className="text-sm">Portfolio rebalancing suggestions</span>
            </label>
          </div>
        </section>
      </div>
    </Layout>
  );
};
