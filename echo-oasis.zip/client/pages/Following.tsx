import { Layout } from "../components/Layout";
import { Trash2, TrendingUp, Heart } from "lucide-react";

export const Following = () => {
  const followedWallets = [
    {
      id: 1,
      address: "0x742d35Cc6634C0532925a3b844Bc92e5b1f6f57a",
      label: "Vitalik Buterin",
      balance: 2450000,
      pnl: 450000,
      pnlPercent: 22.5,
      followers: 15420,
    },
    {
      id: 2,
      address: "0x1234...5678",
      label: "Top Trader",
      balance: 1200500,
      pnl: 280000,
      pnlPercent: 30.2,
      followers: 8950,
    },
    {
      id: 3,
      address: "0xabcd...efgh",
      label: "DeFi Master",
      balance: 890250,
      pnl: 125000,
      pnlPercent: 16.3,
      followers: 5420,
    },
  ];

  return (
    <Layout>
      <div className="p-4 md:p-8 space-y-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Following</h1>
          <p className="text-muted-foreground">
            {followedWallets.length} wallets • Real-time activity updates
          </p>
        </div>

        {/* Activity Feed */}
        <section className="glass-effect p-6 rounded-xl">
          <h2 className="text-xl font-bold mb-6">Recent Activity</h2>
          <div className="space-y-4">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="flex items-start gap-4 p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border-l-2 border-cyan-500/50"
              >
                <div className="w-10 h-10 rounded-full gradient-cyan-purple flex items-center justify-center flex-shrink-0">
                  <span className="text-white text-sm font-bold">V</span>
                </div>
                <div className="flex-1">
                  <p className="font-semibold">
                    Vitalik Buterin swapped 5 ETH for 8,500 USDC
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    5 minutes ago • Uniswap V3 • Value: $14,250
                  </p>
                </div>
                <button className="btn-secondary py-1 px-3 text-sm flex-shrink-0">
                  Copy
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Followed Wallets */}
        <section className="glass-effect p-6 rounded-xl">
          <h2 className="text-xl font-bold mb-6">Your Followed Wallets</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {followedWallets.map((wallet) => (
              <div
                key={wallet.id}
                className="p-6 rounded-lg bg-white/5 hover:bg-white/10 transition-colors border border-white/10"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3 flex-1">
                    <div className="w-12 h-12 rounded-full gradient-cyan-purple flex items-center justify-center">
                      <span className="text-white font-bold">
                        {wallet.label.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <p className="font-semibold">{wallet.label}</p>
                      <p className="text-xs text-muted-foreground">
                        {wallet.address}
                      </p>
                    </div>
                  </div>
                  <button className="p-2 hover:bg-white/10 rounded-lg transition-colors text-red-400 hover:text-red-300">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">
                      Balance
                    </p>
                    <p className="font-semibold">
                      ${(wallet.balance / 1000000).toFixed(1)}M
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">PnL</p>
                    <p className="font-semibold text-green-400 flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      {wallet.pnlPercent.toFixed(1)}%
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
                  <Heart className="w-3 h-3" />
                  {wallet.followers.toLocaleString()} followers
                </div>

                <button className="w-full btn-secondary text-sm">
                  View Wallet
                </button>
              </div>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
};
