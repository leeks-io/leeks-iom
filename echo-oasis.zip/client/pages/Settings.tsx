import { Layout } from "../components/Layout";
import { Moon, Sun, Bell, Lock, Eye, Plus, Trash2 } from "lucide-react";
import { useState } from "react";

export const Settings = () => {
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(true);

  const savedWallets = [
    {
      id: 1,
      address: "0x742d35Cc6634C0532925a3b844Bc92e5b1f6f57a",
      label: "Main Wallet",
    },
    {
      id: 2,
      address: "0x1234567890123456789012345678901234567890",
      label: "Trading Bot",
    },
  ];

  return (
    <Layout>
      <div className="p-4 md:p-8 space-y-8 max-w-3xl">
        <div>
          <h1 className="text-3xl font-bold mb-2">Settings</h1>
          <p className="text-muted-foreground">
            Manage your preferences and connected wallets
          </p>
        </div>

        {/* Profile Section */}
        <section className="glass-effect p-6 rounded-xl">
          <h2 className="text-lg font-bold mb-4">Profile</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Display Name
              </label>
              <input
                type="text"
                placeholder="Your name"
                className="w-full px-4 py-2 rounded-lg glass-dark focus:outline-none focus:ring-2 focus:ring-cyan-500/50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Bio</label>
              <textarea
                placeholder="Tell us about yourself..."
                rows={3}
                className="w-full px-4 py-2 rounded-lg glass-dark focus:outline-none focus:ring-2 focus:ring-cyan-500/50 resize-none"
              />
            </div>
            <button className="btn-primary">Save Changes</button>
          </div>
        </section>

        {/* Saved Wallets */}
        <section className="glass-effect p-6 rounded-xl">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold">Saved Wallets</h2>
            <button className="btn-secondary py-2 px-3 text-sm flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Add Wallet
            </button>
          </div>
          <div className="space-y-3">
            {savedWallets.map((wallet) => (
              <div
                key={wallet.id}
                className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-10 h-10 rounded-full glass-dark flex items-center justify-center">
                    <Eye className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div>
                    <p className="font-semibold">{wallet.label}</p>
                    <p className="text-xs text-muted-foreground">
                      {wallet.address}
                    </p>
                  </div>
                </div>
                <button className="p-2 hover:bg-white/10 rounded-lg transition-colors text-red-400 hover:text-red-300">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Notifications */}
        <section className="glass-effect p-6 rounded-xl">
          <h2 className="text-lg font-bold mb-4">Notifications</h2>
          <div className="space-y-4">
            <label className="flex items-center justify-between cursor-pointer">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-cyan-400" />
                <span className="font-medium">Trade Notifications</span>
              </div>
              <input
                type="checkbox"
                checked={notifications}
                onChange={(e) => setNotifications(e.target.checked)}
                className="w-5 h-5 rounded"
              />
            </label>
            <label className="flex items-center justify-between cursor-pointer">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-purple-400" />
                <span className="font-medium">Price Alerts</span>
              </div>
              <input
                type="checkbox"
                defaultChecked
                className="w-5 h-5 rounded"
              />
            </label>
            <label className="flex items-center justify-between cursor-pointer">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-green-400" />
                <span className="font-medium">Follow Wallet Updates</span>
              </div>
              <input
                type="checkbox"
                defaultChecked
                className="w-5 h-5 rounded"
              />
            </label>
          </div>
        </section>

        {/* Appearance */}
        <section className="glass-effect p-6 rounded-xl">
          <h2 className="text-lg font-bold mb-4">Appearance</h2>
          <label className="flex items-center justify-between cursor-pointer">
            <div className="flex items-center gap-3">
              {darkMode ? (
                <Moon className="w-5 h-5 text-purple-400" />
              ) : (
                <Sun className="w-5 h-5 text-yellow-400" />
              )}
              <span className="font-medium">Dark Mode</span>
            </div>
            <input
              type="checkbox"
              checked={darkMode}
              onChange={(e) => setDarkMode(e.target.checked)}
              className="w-5 h-5 rounded"
            />
          </label>
        </section>

        {/* Security */}
        <section className="glass-effect p-6 rounded-xl">
          <h2 className="text-lg font-bold mb-4">Security</h2>
          <div className="space-y-3">
            <button className="w-full flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-cyan-400" />
                <span className="font-medium">Change Password</span>
              </div>
            </button>
            <button className="w-full flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-purple-400" />
                <span className="font-medium">Two-Factor Authentication</span>
              </div>
            </button>
          </div>
        </section>

        {/* Danger Zone */}
        <section className="glass-effect p-6 rounded-xl border-red-500/30">
          <h2 className="text-lg font-bold mb-4 text-red-400">Danger Zone</h2>
          <button className="w-full px-4 py-2 rounded-lg border border-red-500/50 text-red-400 hover:bg-red-500/10 transition-colors font-medium">
            Delete Account
          </button>
        </section>
      </div>
    </Layout>
  );
};
