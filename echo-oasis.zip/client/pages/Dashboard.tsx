import { Layout } from "../components/Layout";
import { useState } from "react";
import {
  Search,
  TrendingUp,
  TrendingDown,
  Copy,
  Heart,
  RefreshCw,
} from "lucide-react";

interface Portfolio {
  balance: number;
  pnl: number;
  pnlPercent: number;
  topAssets: Array<{
    symbol: string;
    allocation: number;
    price: number;
    change24h: number;
  }>;
}

export const Dashboard = () => {
  const [walletAddress, setWalletAddress] = useState("");
  const [portfolio, setPortfolio] = useState<Portfolio | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = () => {
    if (!walletAddress.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setPortfolio({
        balance: 45230.5,
        pnl: 8450.2,
        pnlPercent: 23.4,
        topAssets: [
          { symbol: "ETH", allocation: 45, price: 2850, change24h: 2.3 },
          { symbol: "USDC", allocation: 25, price: 1, change24h: 0 },
          { symbol: "SOL", allocation: 20, price: 142, change24h: 5.2 },
          { symbol: "PEPE", allocation: 7, price: 0.00000823, change24h: 12.5 },
          { symbol: "ARB", allocation: 3, price: 1.25, change24h: -2.1 },
        ],
      });
      setLoading(false);
    }, 1500);
  };

  return (
    <Layout>
      <div className="p-4 md:p-8 space-y-8">
        {/* Wallet Search */}
        <section className="max-w-2xl">
          <h1 className="text-3xl font-bold mb-4">Dashboard</h1>
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Enter wallet address (0x... or username)"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                className="w-full pl-10 pr-4 py-3 rounded-lg glass-dark focus:outline-none focus:ring-2 focus:ring-cyan-500/50 text-foreground placeholder:text-muted-foreground"
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={loading}
              className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {loading ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                "Search"
              )}
            </button>
          </div>
        </section>

        {/* Portfolio Overview */}
        {portfolio && (
          <>
            {/* Stats Grid */}
            <section className="grid md:grid-cols-3 gap-4">
              <div className="glass-effect p-6 rounded-xl">
                <p className="text-sm text-muted-foreground mb-2">
                  Total Balance
                </p>
                <p className="text-3xl font-bold">
                  $
                  {portfolio.balance.toLocaleString("en-US", {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </p>
              </div>

              <div className="glass-effect p-6 rounded-xl">
                <p className="text-sm text-muted-foreground mb-2">Total PnL</p>
                <div className="flex items-baseline gap-2">
                  <p className="text-3xl font-bold text-green-400">
                    $
                    {portfolio.pnl.toLocaleString("en-US", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}
                  </p>
                  <span className="text-green-400 flex items-center gap-1">
                    <TrendingUp className="w-4 h-4" />
                    {portfolio.pnlPercent.toFixed(1)}%
                  </span>
                </div>
              </div>

              <div className="glass-effect p-6 rounded-xl flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Actions</p>
                  <div className="flex gap-2">
                    <button className="btn-secondary py-1 px-3 text-sm flex items-center gap-1">
                      <Heart className="w-4 h-4" />
                      Follow
                    </button>
                    <button className="btn-secondary py-1 px-3 text-sm flex items-center gap-1">
                      <Copy className="w-4 h-4" />
                      Copy
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* Portfolio Breakdown */}
            <section className="glass-effect p-6 rounded-xl">
              <h2 className="text-xl font-bold mb-6">Top Assets</h2>
              <div className="space-y-4">
                {portfolio.topAssets.map((asset) => (
                  <div
                    key={asset.symbol}
                    className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-10 h-10 rounded-full glass-dark flex items-center justify-center font-bold text-cyan-400">
                        {asset.symbol.charAt(0)}
                      </div>
                      <div>
                        <p className="font-semibold">{asset.symbol}</p>
                        <p className="text-sm text-muted-foreground">
                          $
                          {asset.price.toLocaleString("en-US", {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 8,
                          })}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="font-semibold">{asset.allocation}%</p>
                      <p
                        className={`text-sm flex items-center justify-end gap-1 ${
                          asset.change24h >= 0
                            ? "text-green-400"
                            : "text-red-400"
                        }`}
                      >
                        {asset.change24h >= 0 ? (
                          <TrendingUp className="w-3 h-3" />
                        ) : (
                          <TrendingDown className="w-3 h-3" />
                        )}
                        {Math.abs(asset.change24h).toFixed(1)}%
                      </p>
                    </div>

                    <button className="ml-4 btn-secondary py-1 px-3 text-sm">
                      Copy Trade
                    </button>
                  </div>
                ))}
              </div>
            </section>

            {/* Trade Feed */}
            <section className="glass-effect p-6 rounded-xl">
              <h2 className="text-xl font-bold mb-6">Recent Trades</h2>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center gap-4 flex-1">
                      <div className="w-10 h-10 rounded-full gradient-cyan-purple flex items-center justify-center">
                        <span className="text-white font-bold text-sm">⟷</span>
                      </div>
                      <div>
                        <p className="font-semibold">
                          Swapped 2.5 ETH for 4,200 USDC
                        </p>
                        <p className="text-sm text-muted-foreground">
                          2 hours ago • Uniswap V3
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="font-semibold text-cyan-400">$7,125.00</p>
                      <button className="btn-secondary py-1 px-3 text-sm mt-2">
                        Copy
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </>
        )}

        {!portfolio && !loading && (
          <div className="flex flex-col items-center justify-center py-20 glass-effect p-8 rounded-xl text-center">
            <Search className="w-16 h-16 text-muted-foreground/50 mb-4" />
            <p className="text-lg text-muted-foreground">
              Enter a wallet address to get started
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
};
